﻿# AlphaTab Xamarin Forms Android Sample

 This sample shows how to embedd alphaTab into a Xamarin Forms App targeting Android. The sample loads an embedded Guitar Pro file and displays it using 
 the Xamarin Forms Control provided by alphaTab.