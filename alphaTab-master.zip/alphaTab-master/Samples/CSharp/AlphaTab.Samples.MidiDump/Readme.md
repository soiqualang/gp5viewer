﻿# AlphaTab Midi Dump Sample

This sample reads a given input file and generates a midi file containing the audio information for the file. 