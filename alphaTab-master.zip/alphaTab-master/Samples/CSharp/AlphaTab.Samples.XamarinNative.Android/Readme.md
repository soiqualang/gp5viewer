﻿# AlphaTab Xamarin Native Android Sample

 This sample shows how to embedd alphaTab into a Xamarin App targeting Android. The sample loads an embedded Guitar Pro file and displays it using 
 the Xamarin Control provided by alphaTab.