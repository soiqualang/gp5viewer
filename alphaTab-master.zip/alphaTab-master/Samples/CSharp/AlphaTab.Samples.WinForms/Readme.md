﻿# AlphaTab WinForms Sample

This sample uses GDI+ or SkiaSharp (user choice) as drawing engine and uses the WinForms Control to actually display the rendered image.