﻿using System;

namespace AlphaTab
{
    public class Class1
    {
    }
}
